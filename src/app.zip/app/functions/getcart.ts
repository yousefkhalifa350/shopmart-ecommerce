'use server'
import { CartResponse } from "@/interfaces"
import { decode } from "next-auth/jwt"
import { cookies } from "next/headers"
import { GetUserToken } from "../Helpers/GetUserToken"





 export async function GetCartItem() { 

const token = await GetUserToken()

const response = await fetch(`${'https://ecommerce.routemisr.com/api/v1'}/cart` , 

        {

            headers:{
                 token:token!,
            }

        }

    )

const data : CartResponse  = await response.json()

return data

}
