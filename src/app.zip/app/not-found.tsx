import React from 'react'

export default function Notfound() {
  return (
 <>
 
 <div className="min-h-screen flex justify-center items-center ">

<h1>Not Found !! 404....</h1>

 </div>
 </>
  )
}
 