'use client'
import Image from "next/image";
import { useSession } from 'next-auth/react'
export default function Home() {


const mysession = useSession()

console.log(mysession);


  return (
 <section className="flex flex-col items-center justify-center text-center py-20 px-4 bg-white">
      {mysession.status=='authenticated'&& <h2  className="text-xl text-gray-600 mb-2">Helloo.. {mysession.data.user.name}</h2>}
      <h2></h2>

      <p className=" font-bold mb-4 text-5xl">
        Welcome to ShopMart
      </p>

      <p className="text-gray-600 max-w-2xl text-lg mb-8">
        Discover the latest technology, fashion, and lifestyle products. 
        Quality guaranteed with fast shipping and excellent customer service.
      </p>

      <div className="flex gap-4">
        <button className="bg-black text-white py-3 px-6 rounded-lg hover:bg-gray-800 transition cursor-pointer ">
          Shop Now
        </button>

        <button className="border border-black py-3 px-6 rounded-lg hover:bg-gray-100 transition cursor-pointer">
          Browse Categories
        </button>
      </div>
    </section>
  );
}
