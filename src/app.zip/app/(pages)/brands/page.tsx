'use server'
import { Brand } from '@/interfaces';
import Image from 'next/image';
import React from 'react'

 export  default async function Brands() {

const response = await fetch ('https://ecommerce.routemisr.com/api/v1/brands',{next: { revalidate: 300 }})

const {data:brand} :{data:Brand[]}  =  await response.json()

console.log(brand);




  return (
    <>
    

<div className='grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mx-3 my-3'>
  {brand.map((thebrand) => (
    <div 
      key={thebrand._id}
      className="bg-white rounded-xl flex flex-col items-center justify-center cursor-pointer transition-transform duration-300 hover:shadow-lg hover:scale-90 border-2 p-4"
    >
      <Image 
        src={thebrand.image} 
        alt={thebrand.name} 
        width={350} 
        height={270} 
        className='w-full h-[180px] object-cover rounded-lg mb-3'
      />
      <p className="text-lg font-medium text-center">{thebrand.name}</p>
    </div>
  ))}
</div>






    
    </>
  )
}
