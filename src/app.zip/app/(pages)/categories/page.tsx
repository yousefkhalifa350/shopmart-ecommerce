import React from 'react'

export default function Cart() {
  return (
//   <div className="
//   text-[3rem]
//   font-bold
  
//   tracking-[2px]
//   uppercase
//   relative
//   inline-block
//   cursor-pointer
//   transition-all
//   duration-300
//   ease-in-out
//   hover:text-[#feb47b]
//   hover:scale-105

//   after:content-['']
//   after:w-[60%]
//   after:h-[4px]
//   after:bg-gradient-to-r
//   after:from-[#ff7e5f]
//   after:to-[#feb47b]
//   after:absolute
//   after:left-1/2
//   after:-bottom-[10px]
//   after:-translate-x-1/2
//   after:rounded
//   after:transition-all
//   after:duration-300
//   hover:after:w-full
// ">
//   Shop mart
// </div>


<>

<h1>Catego</h1>

</>






  )
}
