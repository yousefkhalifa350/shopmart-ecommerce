'use server'
import Image from 'next/image';
import { Product } from '@/interfaces';
import { log } from 'node:console'
import React from 'react'
 import { Button } from "@/components/ui/button"
import {
  Card,
  CardAction,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import MystarIcon from '@/components/ui/mystarIcon/mystarIcon';
import { HeartIcon } from 'lucide-react';
import Link from 'next/link';
import Addtocart from '@/components/ui/Addcart/addtocart';
import ProductDetails from './[productId]/page';






export default async function Products() {

const response = await fetch('https://ecommerce.routemisr.com/api/v1/products',{next: { revalidate: 300 }})

const {data:product}:{data:Product[]} = await response.json()
console.log(product);



  return (
   <>
   
   
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 pt-5">
      {product.map((product)=><div key={product.id}>

     <Card className='
    group 
    transition-all duration-300
    hover:shadow-xl
    hover:-translate-y-1 
  "'>
<Link href={'/products/'+product.id}>
  <CardHeader>

<Image loading="lazy" src={product.imageCover} alt={product.imageCover}  width={400}  height={300} className=' src={product.imageCover}
  width={400}
  height={300}
  alt=""
  className="
    w-full
    transition-transform duration-300
    group-hover:scale-105'  />
    <CardDescription>{product.brand.name}</CardDescription>
    <CardTitle>{product.title.split('' , 6).join('')}</CardTitle>
    <CardDescription>{product.category.name}</CardDescription>

  </CardHeader>
  <CardContent>
   

<div className='flex'>

 <MystarIcon/>
 <MystarIcon/>
 <MystarIcon/>
 <MystarIcon/>

  <p> {product.ratingsAverage}  </p>



</div>

<p className='pt-1'>  Price: <span className=' font-bold'>EGB {product.price}</span>  </p>
  </CardContent>

  </Link>

<Addtocart productId ={product.id}/>

</Card>




</div>)}
    </div>
   
   
   
   </>
  )


}
