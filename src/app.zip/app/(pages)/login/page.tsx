'use client'
import React, { useState } from 'react'
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import {signIn} from 'next-auth/react' 
import { Button } from "@/components/ui/button"
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Card } from '@/components/ui/card'
import { useSearchParams } from 'next/navigation'
import { Loader, Loader2 } from 'lucide-react'

//shakl l data 3ndkk
const formSchema = z.object({

email:z.email('Invalid Email!').nonempty('Email is required'),
password:z.string('Password is not valid!').nonempty('Password is required').min(6,'Min length is 6 char!')

})



//type of te data and value of Zod 
type FormFields = z.infer<typeof formSchema>

export default function Login() {
    const [isloading, setIsloading] = useState(false)
const SearchParams = useSearchParams()
console.log(SearchParams.get('error'));




// 1. Define your form.
const form = useForm<FormFields>({
    resolver: zodResolver(formSchema),
    defaultValues: {
    email:'', 
    password:'',
    },
  })
 


  //Take the data from our end and send to next-auth
  async function onSubmit(values:FormFields) {
    // Do something with the form values.
    // ✅ This will be type-safe and validated.

setIsloading(true)

const response = await signIn("credentials", {

email:values.email,
password:values.password,
callbackUrl:'/products',
redirect:true
})

    console.log(response)
    setIsloading(false)
  }




  return (
<>

<div className="min-h-screen grid grid-cols-1  lg:grid-cols-2 bg-[#f6f7fb]">

  {/* ================= LEFT PANEL ================= */}
  <div className="
    hidden lg:flex items-center justify-center px-6
  ">
    <div className="
      relative w-full max-w-md h-[520px]
      rounded-[36px] overflow-hidden
    ">

      {/* Gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-orange-500 to-orange-400" />

      {/* Grain */}
      <div
        className="absolute inset-0 opacity-10 pointer-events-none
        bg-[url('data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22200%22 height=%22200%22%3E%3Cfilter id=%22n%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.8%22 numOctaves=%223%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23n)%22 opacity=%220.4%22/%3E%3C/svg%3E')]"
      />

      {/* Content */}
      <div className="relative z-10 h-full p-8 flex flex-col justify-between text-white">
        <div>
          <h2 className="text-3xl font-bold leading-tight">
            Simplify<br />
            management with<br />
            our dashboard.
          </h2>

          <p className="mt-4 text-sm opacity-90">
            Simplify your e-commerce management with our user-friendly admin dashboard.
          </p>
        </div>





        {/* image placeholders */}
        <div className="flex items-end justify-center gap-6">
          <div className="w-24 h-32 bg-white/20 rounded-xl" />
          <div className="w-24 h-32 bg-white/20 rounded-xl" />
        </div>
      </div>
    </div>
  </div>  

  {/* ================= RIGHT FORM ================= */}
  <div className="
    flex flex-col justify-center items-center px-4
    order-2 lg:order-none
  ">
    <div className="w-full max-w-md">

<div className="flex flex-col items-center gap-2 mb-8">

  {/* ===== Brand ===== */}
  <div className="flex items-center gap-4 group cursor-pointer">
    <div
      className="
        w-13 h-13 rounded-full
        bg-orange-500 text-white
        flex items-center justify-center
        font-extrabold text-xl
        transition-transform duration-300
        group-hover:scale-110
      "
    >
      S
    </div>

    <span
      className="
            text-3xl sm:text-6xl font-extrabold text-gray-900
        tracking-tight
        transition-colors duration-300
        group-hover:text-orange-500re
      "
    >
      ShopMart
    </span>
  </div>

  {/* ===== Welcome Back ===== */}
  <h1
    className="
         relative text-2xl sm:text-4xl font-semibold text-gray-800
      transition-transform duration-300
      hover:scale-[1.02]
      after:content-['']
      after:absolute after:left-1/2 after:-bottom-2
      after:-translate-x-1/2
      after:w-0 after:h-[2px]
      after:bg-orange-500
      after:transition-all after:duration-300
      hover:after:w-1/3
    "
  >
    Welcome Back
  </h1>

  {/* ===== Subtitle ===== */}
  <p className="text-sm text-gray-400 text-center">
    Please login to your account
  </p>

</div>


      <Card className="p-7 rounded-xl shadow-sm bg-white">

        <Form {...form}>
          {SearchParams.get("error") && (
            <p className="text-red-600 text-sm mb-4 text-center">
              {SearchParams.get("error")}
            </p>
          )}

          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="space-y-6"
          >

            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Yousef@example.com"
                      className="bg-gray-100 focus:bg-white"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Password</FormLabel>
                  <FormControl>
                    <Input
                      type="password"
                      className="bg-gray-100 focus:bg-white"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button
              type="submit"
              className="w-full bg-orange-500 hover:bg-orange-600 text-white cursor-pointer"
            >
              {isloading ? <Loader2 className="animate-spin " /> : "Login"}
            </Button>

          </form>
        </Form>

      </Card>
    </div>
  </div>

</div>



</>
  )
}
