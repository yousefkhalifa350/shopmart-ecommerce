import React from 'react'

export default function profile() {
  return (
    <nav className="relative flex gap-6 text-sm font-medium">
  <span className="nav-item">Login</span>
  <span className="nav-item">Favorites</span>
  <span className="nav-item">Shopping Cart</span>

  {/* underline */}
  <span className="nav-underline" />
</nav>
  )
}
